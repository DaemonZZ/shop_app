class CartItem {
  final int id, idCart, isProduct;

  CartItem(this.id,this.idCart,this.isProduct);
}