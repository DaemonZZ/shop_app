class Cart {
  final int id;
  final int user;
  Cart(this.id,this.user);
}