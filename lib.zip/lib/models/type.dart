class ProductType {
  final int id;
  final String typeName;

  ProductType(this.id,this.typeName);
}