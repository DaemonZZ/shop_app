class User{
   final int id;
   String name,address,phone;

  User(this.id,{this.name='',this.address='',this.phone=''});
}