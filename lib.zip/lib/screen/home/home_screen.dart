import 'package:flutter/material.dart';

import 'component/body.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  AppBar buildAppBar(BuildContext context){
    return AppBar(
      leading: IconButton(
        icon: const IconTheme(
            data: IconThemeData(color: Colors.black54),
            child: Icon(Icons.arrow_back)),
        onPressed: () {},
      ),
      title: Text(
        "Shop App demo",
        style: Theme.of(context).textTheme.headline4,
      ),
      backgroundColor: Colors.white,
      actions: [
        IconButton(
            onPressed: () {},
            icon: const IconTheme(
              data: IconThemeData(color: Colors.black54),
              child: Icon(Icons.search),
            )),
        IconButton(
            onPressed: () {},
            icon: const IconTheme(
              data: IconThemeData(color: Colors.black54),
              child: Icon(Icons.shopping_cart),
            )),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(context) ,
      body: Body(),
    );
  }

}
