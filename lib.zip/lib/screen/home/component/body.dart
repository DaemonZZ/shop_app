import 'package:flutter/material.dart';
import 'package:shop_app_example/constants.dart';
import 'package:shop_app_example/models/product.dart';
import 'package:shop_app_example/screen/detail/detail_screen.dart';

import 'categories.dart';
import 'item_card.dart';

class Body extends StatelessWidget {
  const Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: kDefaultPadding / 2,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
          child: Text(
            "Women",
            style: Theme.of(context).textTheme.headline3,
          ),
        ),
        const Categories(),
        Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
              child: GridView.builder(
                  itemCount: products.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.75,
                    mainAxisSpacing: kDefaultPadding,
                    crossAxisSpacing: kDefaultPadding
                  ),
                  itemBuilder: (context, index) {
                    return ItemCard(
                      product: products[index],
                      press: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context){
                            return Detail(products[index]);
                          }
                        ));
                      },
                    );
                  }),
            ))
      ],
    );
  }
}

