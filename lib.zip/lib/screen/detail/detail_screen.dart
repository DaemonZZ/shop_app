import 'package:flutter/material.dart';
import 'package:shop_app_example/constants.dart';
import 'package:shop_app_example/models/product.dart';

class Detail extends StatelessWidget {
  final Product _product;

  const Detail(this._product, {Key? key}) : super(key: key);

  AppBar buildAppBar(BuildContext context) {
    return AppBar(
      leading: IconButton(
        icon: const IconTheme(
            data: IconThemeData(color: Colors.black54),
            child: Icon(Icons.arrow_back)),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        _product.title,
        style: Theme.of(context).textTheme.headline4,
      ),
      backgroundColor: Colors.white,
      actions: [
        IconButton(
            onPressed: () {},
            icon: const IconTheme(
              data: IconThemeData(color: Colors.black54),
              child: Icon(Icons.search),
            )),
        IconButton(
            onPressed: () {},
            icon: const IconTheme(
              data: IconThemeData(color: Colors.black54),
              child: Icon(Icons.shopping_cart),
            )),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(context),
      body: DetailBody(_product),
    );
  }
}

class DetailBody extends StatelessWidget {
  final Product _product;

  const DetailBody(this._product, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(kDefaultPadding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            child: Padding(
              padding: const EdgeInsets.all(kDefaultPadding),
              child: Image.asset(
                _product.image,
                fit: BoxFit.fill,
              ),
            ),
            decoration: BoxDecoration(
                color: Color(_product.colorCode), borderRadius: BorderRadius.circular(16)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: kDefaultPadding / 2),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _product.title,
                  style: Theme.of(context).textTheme.headline5,
                ),
                Text(
                  "\$${_product.price}",
                  style: Theme.of(context).textTheme.headline5,
                )
              ],
            ),
          ),

          Text("Size: ${_product.size}" , style: Theme.of(context).textTheme.headline5,),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: kDefaultPadding/2),
            child: Text(_product.description,
              style: const TextStyle(fontSize: 16),
            ),
          ),
          ElevatedButton.icon(
            onPressed: () {},
            label: const Text("Add to cart"),
            icon: const Icon(Icons.shopping_cart),
          ),
        ],
      ),
    );
  }
}
